<?php

$host="localhost"; // Host name 
$username=""; // Mysql username 
$password=""; // Mysql password 
$db_name="test"; // Database name
$tbl_name="order"; // Table name

// Connect to server and select databse.
$con = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");

// Information sent from track order form
$myorderid=$_POST['myorderid'];

//new queries

$sql="SELECT orderid FROM $tbl_name WHERE orderid='$myorderid'";
$result=mysqli_query($con,$sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

if($count==1)
{
 $info = mysqli_fetch_array( $result );
 echo $info;
header("location:trackorder1.html");
}
else
{
echo "error";
 header("location:trackorder2.html");
}

?>