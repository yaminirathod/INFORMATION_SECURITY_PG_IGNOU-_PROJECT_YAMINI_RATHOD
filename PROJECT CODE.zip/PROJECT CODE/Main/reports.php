<?php
 
 session_start();

$host="localhost"; // Host name 
$username=""; // Mysql username 
$password=""; // Mysql password 
$db_name="test"; // Database name 
$tbl_name="customer"; // Table name 

// Connect to server and select databse.
$con = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>View Reports</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->
</head>
<body>
<div class="main">

  <div class="header">
    <div class="header_resize">
      <div class="logo"><h1><a href="index.html" class="nobg">Inventory Management System</a></h1></div>
      <div class="menu_nav">
        <ul>
          <li><a href="main.html">Home</a></li>
          <li><a href="loginmain1.html">LogIn</a></li>
		  <li><a href="signup.html">Sign Up</a></li> 
          <li><a href="aboutus.html">About Us</a></li>
          <li><a href="contactus.html">Contact Us</a></li>
		  <li><a href="gst.html">GST</a></li>
			<li><a href="support.html">Support</a></li>
			<li><a href="sale.html">Sale</a></li>
			<li class="active"><a href="reports.html">Reports</a></li>
		  <li><a href="faq.html">FAQ</a></li>
        </ul>
      </div>
      <div class="clr"></div>
    </div>
  </div>

  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2>Welcome Admin!!</h2>
          
          <?php
		  
	 $sql = "select * from $tbl_name";
	$result=mysqli_query($con,$sql);
	
	echo "<table>";
	
	while($row=mysqli_fetch_array($result))
	
	echo "<tr><td>Customername:$row[1]</td></tr><tr><td>Password:$row[2]</td></tr><tr><td>Address:$row[5]</td></tr><tr><td>Email-ID:$row[6]</td></tr><tr><td>Contacts:$row[7]</td></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr>";
 
	echo "</table>";
		  
		  ?>
		  
        </div>
        
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star">Menu</h2>
          <ul class="sb_menu">
		    <li><a href="main.html">Home</a></li>
            <li><a href="loginmain1.html">LogIn</a></li>
            <li><a href="signup.html">Sign Up</a></li> 
            <li><a href="aboutus.html">About us</a></li>
			<li><a href="contactus.html">Contact Us</a></li>
			<li><a href="gst.html">GST</a></li>
			<li><a href="support.html">Support</a></li>
			<li><a href="sale.html">Sale</a></li>
			<li class="active"><a href="reports.html">Reports</a></li>
            <li><a href="faq.html">FAQ</a></li>
            
          </ul>
        </div>
        
      </div>
      <div class="clr"></div>
    </div>
  </div>

  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        <h2>Image Gallery</h2>
        <a href="#" class="nobg"><img src="img/13.jpg" width="64" height="64" alt="ad" class="ad" /></a>
        <a href="#" class="nobg"><img src="img/12.jpg" width="64" height="64" alt="ad" class="ad" /></a>
        <a href="#" class="nobg"><img src="img/11.jpg" width="64" height="64" alt="ad" class="ad" /></a>
        <a href="#" class="nobg"><img src="img/10.jpg" width="64" height="64" alt="ad" class="ad" /></a>
        <a href="#" class="nobg"><img src="img/5.jpg" width="64" height="64" alt="ad" class="ad" /></a>
        <a href="#" class="nobg"><img src="img/6.jpg" width="64" height="64" alt="ad" class="ad" /></a>
        <a href="#" class="nobg"><img src="img/7.jpg" width="64" height="64" alt="ad" class="ad" /></a>
        <a href="#" class="nobg"><img src="img/8.jpg" width="64" height="64" alt="ad" class="ad" /></a>
        <a href="#" class="nobg"><img src="img/9.jpg" width="64" height="64" alt="ad" class="ad" /></a>
        <div class="clr"></div>
      </div>
      <div class="col c2">
        <h2>About</h2>
        <p>This is the version 1.0 for the inventory management system. It implements the basic functionalities of Inventory Management.</p>
        <ul class="sb_menu">
          <li>Yamini Rathod</li>
          <li>Computer Science Engineer</li>
        </ul>
        
      </div>
      <div class="col c3">
        <h2>Contact</h2>
        <img src="img/14.jpg" width="64" height="64" alt="white" />
        <p>You may contact us for the further advancements and any queries.</p>
        <p>
          <strong>E-mail : </strong>yamini.ce94@gmail.com</p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright. Designed by Yamini Rathod.</p>
      <ul class="fmenu">
        <li><a href="main.html">Home</a></li>
        <li><a href="loginmain1.html">LogIn</a></li> 
		<li><a href="signup.html">Sign Up</a></li> 
        <li><a href="aboutus.html">About Us</a></li>
        <li><a href="contactus.html">Contact Us</a></li>
		<li><a href="gst.html">GST</a></li>
			<li><a href="support.html">Support</a></li>
			<li><a href="sale.html">Sale</a></li>
			<li class="active"><a href="reports.html">Reports</a></li>
		<li><a href="faq.html">FAQ</a></li>
      </ul>
      <div class="clr"></div>
    </div>
  </div>
</div>
</body>
</html>
