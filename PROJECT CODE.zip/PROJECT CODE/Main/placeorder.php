<?php

$host="localhost"; // Host name 
$username=""; // Mysql username 
$password=""; // Mysql password 
$db_name="test"; // Database name
$tbl_name="order"; // Table name

// Connect to server and select databse.
$con = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");

// Information sent from place order form
$myorderid=$_POST['myorderid']; 
$mytypeofgoods=$_POST['mytypeofgoods'];
$myorderdate=$_POST['myorderdate'];
$mywithdrawdate=$_POST['mywithdrawdate']; 
$myvalueofgoods=$_POST['myvalueofgoods']; 

//new queries

//$sql="insert into $tbl_name (orderid,orderdate,withdrawdate,valueofgoods) VALUES ('$myorderid','$myorderdate','$mywithdrawdate','$myvalueofgoods')";
$sql = "INSERT INTO `test`.`order` (`orderid`) VALUES ('$myorderid')";


//echo $sql;
//$result=mysqli_query($con,$sql);

//$query = "INSERT INTO `login`.`order` (`orderid`, `typeofgoods`, `orderdate`, `withdrawdate`, `valueofgoods`) VALUES ('$orderid', '$typeofgoods', '$orderdate', '$withdrawdate', '$valueofgoods')";

// Mysql_num_row is counting table row
//$count=mysqli_num_rows($result);

//if($count==1){

header("location:placeorder1.html");
//}
//else {
//echo "order not placed";

//}
?>