<?php

$host="localhost"; // Host name 
$username=""; // Mysql username 
$password=""; // Mysql password 
$db_name="test"; // Database name
$tbl_name="customer"; // Table name

// Connect to server and select databse.
$con = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");

// Information sent from signup form
$mycustomername=$_POST['mycustomername']; 
$mypassword=$_POST['mypassword'];
$myans=$_POST['myans'];
$myaddress=$_POST['myaddress']; 
$mycontact=$_POST['mycontact']; 
$myemailid=$_POST['myemailid']; 

// Password Encryption
$mypassword=md5($mypassword);
$myans=md5($myans);

//new queries

$sql="insert into $tbl_name (customername,password,answer,address,contact,emailid) VALUES ('$mycustomername','$mypassword','$myans','$myaddress','$mycontact','$myemailid')";
$result=mysqli_query($con,$sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

if($count==1){

header("location:loginmain2.html");
}
else {
//echo "Wrong Username or Password";
header("location:afterlogin.html");
}

?>