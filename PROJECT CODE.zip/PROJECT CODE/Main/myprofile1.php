<?php
 
 session_start();

$host="localhost"; // Host name 
$username=""; // Mysql username 
$password=""; // Mysql password 
$db_name="test"; // Database name 
$tbl_name="members"; // Table name 

// Connect to server and select databse.
$con = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>View My Profile</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style1.css" rel="stylesheet" type="text/css" />
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js1/cufon-yui.js"></script>
<script type="text/javascript" src="js1/arial.js"></script>
<script type="text/javascript" src="js1/cuf_run.js"></script>
<!-- CuFon ends -->
</head>
<body>
<div class="main">

  <div class="header">
    <div class="header_resize">
      <div class="logo"><h1><a href="index.html">Inventory Management System<br /><small><MARQUEE>Your goods, Our responsibility</MARQUEE></small></a></h1></div>
      
	  <div class="clr"></div>
      
      <div class="clr"></div>
    </div>
  </div>

  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Welcome !!!</span></h2>
          <p>
		  	
			<?php

			$mycontact=$_POST['mycontact']; 
			
			$sql = "select * from $tbl_name where contact='$mycontact'";
			//$sql = "select * from $tbl_name";
			$result=mysqli_query($con,$sql);
			$count=mysqli_num_rows($result);
			
			if($count==1){
	
		$sql = "select * from $tbl_name";
			$result=mysqli_query($con,$sql);
	
	echo "<table>";
	
	while($row=mysqli_fetch_array($result))
	echo "<tr><td>Customername:$row[1]<td><td><td>Password:$row[2]<tr><td></tr><br>";
 
	echo "</table>";
	}
	else
	{
	echo "Wrong contact info";
	}
			
			?>


			</p>
          
          <p class="lbg">Mar 01, 2018</p><br>
		  <p class="lbg"><a href="main.html">Logout</a></p>
        </div>
        
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Menu</span></h2>
          <ul class="sb_menu">
            <li><a href="main.html">Home</a></li>
			<li><a href="myprofile.html">View My Profile</a></li>
			<li class="active"><a href="loginmain1.html">LogIn</a></li>
			<li><a href="signup.html">Sign Up</a></li>
			<li><a href="aboutus.html">About Us</a></li>
            <li><a href="contactus.html">Contact Us</a></li>
			<li><a href="gst.html">GST</a></li>
			<li><a href="support.html">Support</a></li>
			<li><a href="sale.html">Sale</a></li>
			<li><a href="reports.html">Reports</a></li>
            <li><a href="faq.html">FAQ</a></li>
        </ul>
        </div>
        
      </div>
      <div class="clr"></div>
    </div>
  </div>

  
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright. Designed by Yamini Rathod.</p>
      <ul class="fmenu">
        <li><a href="main.html">Home</a></li>
		    <li><a href="myprofile.html">View My Profile</a></li>
			<li class="active"><a href="loginmain1.html">LogIn</a></li>
			<li><a href="signup.html">Sign Up</a></li>
			<li><a href="aboutus.html">About Us</a></li>
            <li><a href="contactus.html">Contact Us</a></li>
			<li><a href="gst.html">GST</a></li>
			<li><a href="support.html">Support</a></li>
			<li><a href="sale.html">Sale</a></li>
			<li><a href="reports.html">Reports</a></li>
            <li><a href="faq.html">FAQ</a></li>
      </ul>
      <div class="clr"></div>
    </div>
  </div>
</div>
</body>
</html>
