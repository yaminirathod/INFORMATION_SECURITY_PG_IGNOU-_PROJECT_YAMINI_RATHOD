<?php

$host="localhost"; // Host name 
$username=""; // Mysql username 
$password=""; // Mysql password 
$db_name="test"; // Database name
$tbl_name="customer"; // Table name

// Connect to server and select databse.
$con = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");

// Username and password sent from form 
$mycustomername=$_POST['mycustomername']; 
$mypassword=$_POST['mypassword'];

// Password Encryption
$mypassword=md5($mypassword);

//new queries

$sql="SELECT * FROM $tbl_name WHERE customername='$mycustomername' and password='$mypassword'";
$result=mysqli_query($con,$sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

if($count==1){

$_SESSION['luser'] = $mycustomername;

if(isset($_SESSION['luser']) && $_SESSION['luser'] =="bibu")
	{
  //your content
  echo "Sorry..! You don't have permission to access this page! Please contact Admin.";
}
else

header("location:loginmain2.html");
}
else {
//echo "Wrong Username or Password";
header("location:loginfail1.html");
}

?>