<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html"; charset=utf-8" />
	<title>XSS</title>
</head>
<body>

 <?php
	if(isset($_POST['input']))
		{
			$data = $_POST['input'];
			echo "<p align='center'>$data</p>";
		}
	?>
	
	<!--
	//<strong>test</strong>
	//<script type="text/javascript">window.location = 'https://google.com';</script>
	-->
	
	<form action="" method="post">
	<h1 align="center">Cross Site Scripting Demo</h1>
	<p align="center">
	<textarea name="input" rows="10" cols="30"></textarea>
	</p>
	<p align="center">
	<input type="submit" value="Submit" />
	</p>
	</form>
	<p align="center">&copy; Copyright. Designed by Yamini Rathod.</p>
<p align="center">&copy; Copyright. This Demo has been Implemented towards the partial fulfillment of the requirements for the degree of Post Graduate Diploma In Information Security (PGDIS) of Indira Gandhi National Open University, New Delhi is the record of work carried out by her.</p>

</body>
</html>