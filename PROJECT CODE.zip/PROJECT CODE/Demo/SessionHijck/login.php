<h1 align="center">Session Hijacking Demo</h1>

<?php

	session_start();
	
	$_SESSION['cookie']=true;
	
	echo "<p align='center'>You are Currently logged-in..!!</p>";

?>

<script type="text/javascript">

	var a=document.cookie;
	alert(a);

</script>

<p align="center">&copy; Copyright. Designed by Yamini Rathod.</p>
<p align="center">&copy; Copyright. This Demo has been Implemented towards the partial fulfillment of the requirements for the degree of Post Graduate Diploma In Information Security (PGDIS) of Indira Gandhi National Open University, New Delhi is the record of work carried out by her.</p>