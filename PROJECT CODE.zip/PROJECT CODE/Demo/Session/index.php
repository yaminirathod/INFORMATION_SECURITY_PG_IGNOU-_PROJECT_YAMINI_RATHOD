 <?php
session_start();
if(@$_POST['submit1'])
{
	$u = $_POST['myusername'];
	$p = $_POST['mypassword'];
	if($u =="admin" && $p=="admin")
	{
	$_SESSION['luser'] = $u;
	$_SESSION['start'] = time();
	 // taking now logged in time
	$_SESSION['expire'] = $_SESSION['start'] + (10) ; 
	// ending a session in 10 secs from the starting time
	header('Location: HomePage.php');
	}
	else
	{
	$err= "<font color='red'>Invalid user login </font>";
	}
}
?>

<html>
<head>
	<title>Destroy Session after 10 secs</title>
</head>
<body>

<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<h1 align="center">Session Management! Destroy Session after 10 secs!</h1>
<form name="form1" method="post">
<td>
<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<td colspan="3"><strong>Member Login </strong></td>
</tr>
<tr>
<td width="78">Username</td>
<td width="6">:</td>
<td width="294"><input name="myusername" type="text" id="myusername"></td>
</tr>
<tr>
<td>Password</td>
<td>:</td>
<td><input name="mypassword" type="password" id="mypassword"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><input type="submit" name="submit1" value="Login"></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
<p align="center">&copy; Copyright. Designed by Yamini Rathod.</p>
<p align="center">&copy; Copyright. This Demo has been Implemented towards the partial fulfillment of the requirements for the degree of Post Graduate Diploma In Information Security (PGDIS) of Indira Gandhi National Open University, New Delhi is the record of work carried out by her.</p>
</body>
</html>