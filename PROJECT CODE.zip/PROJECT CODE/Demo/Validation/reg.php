<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<!--validation starts here -->

<script type="text/javascript">

function check1()
{

    if(signupform.NAME.value=="")
	{
         window.alert("Please enter valid name..!! It can not be blank..!!");
window.event.returnValue=false;
           return false;
	}
	
	if(signupform.PASSWORD.value=="")
	{
         window.alert("Please enter valid password..!! It can not be blank..!!");
window.event.returnValue=false;
           return false;
	}
	
		if(signupform.PASSWORD.value.length<8 || signupform.PASSWORD.value.length>16)
	{
	 window.alert("The password should be of minimum 8 characters and maximum 16 characters.");
 window.event.returnValue=false;
               return false;
	}
	
	//var flag=0,k=0,flag1=0,flag2=-0;
  //               for(var i='A';i<='Z';i++)
    //            {
	//if(signupform.PASSWORD.value.charAt(k)==i)
	//{
      //          flag=1;
       //         break;
	//}
      //          k++;
        //        }
          //       	if(flag==1)
            //    	{
		//k=0; 
		//flag1=0;
			//for(var i='a';i<='z';i++)
			//{ 
			//if(signupform.PASSWORD.value.charAt(k)==i)
			//{
			//flag1=1;
			//break;
			//}
			//k++;
			//}
	//	}		
		//if(flag1==1)
    		//{
		//k=0; 
		//flag2=0;
			//for(var i='0';i<='9';i++)
			//{ 
			//if(signupform.PASSWORD.value.charAt(k)==i)
			//{
			//flag2=1;
			//break ;
			//}
			//k++;
			//}
	//	}
           	
      //                                   if(flag2!=1)
	//	{
	//	window.alert("Password should contain small and capital alphabets and digit");
//window.event.returnValue=false;
	//	 return false;
      //          }


	if(signupform.REPASSWORD.value=="")
	{
         window.alert("Please re-enter same password..!! It can not be blank..!!");
window.event.returnValue=false;
           return false;
	}
	
	if(signupform.PASSWORD.value.length!=signupform.REPASSWORD.value.length )
	{
	window.alert("Retype the password correctly..!!");
window.event.returnValue=false;
                 return false;	
                  }
	
}
</script>

<!--validation ends here -->

<HTML>
<HEAD>
<TITLE>Validation</TITLE>
</HEAD>
<BODY TEXT=BLACK >

<FORM METHOD="POST" ACTION="P1.HTML" name="signupform" id="signupform" onSubmit="JavaScript:check1();">
<h1 align="center">Data Validation Demo</h1>
<p align="center">&copy; Copyright. Designed by Yamini Rathod.</p>
<p align="center">&copy; Copyright. This Demo has been Implemented towards the partial fulfillment of the requirements for the degree of Post Graduate Diploma In Information Security (PGDIS) of Indira Gandhi National Open University, New Delhi is the record of work carried out by her.</p>
<HR SIZE=7 NOSHADE>
<H6 ALIGN=CENTER><STRONG><FONT SIZE=3>STUDENT REGISTRATION FOR ONLINE EXAM</FONT></STRONG></H6>
<HR SIZE=7 NOSHADE>
<TABLE>

<TR>
<TD>ENTER STUDENT NAME : </TD>
<TD><INPUT TYPE=TEXT NAME="NAME" VALUE="ENTER YOUR NAME" SIZE=25 MAXLENGTH=30></TD>
 </TR>

<TR>
<TD>ENTER YOUR PASSWORD : </TD>
<TD><INPUT TYPE=PASSWORD NAME="PASSWORD"  SIZE=20 MAXLENGTH=25></TD>
</TR>

<TR>
<TD>RE-ENTER YOUR PASSWORD : </TD>
<TD><INPUT TYPE=PASSWORD NAME="REPASSWORD"  SIZE=20 MAXLENGTH=25></TD>
</TR>
 
<TR>
<TD>ENTER STUDENT EMAIL : </TD>
<TD><INPUT TYPE=TEXT NAME="STUDENT EMAIL ID" VALUE="ENTER YOUR EMAIL ID" SIZE=20 MAXLENGTH=25></TD>
</TR>

<TR>
<TD> ENTER THE DATE OF BIRTH </TD>
<TD> DATE :
<SELECT NAME=DATE>
<OPTION>1</OPTION>
<OPTION>2</OPTION>
<OPTION>3</OPTION>
<OPTION>4</OPTION>
<OPTION>5</OPTION>
<OPTION>6</OPTION>
<OPTION>7</OPTION>
<OPTION>8</OPTION>
<OPTION>9</OPTION>
<OPTION>10</OPTION>
<OPTION>11</OPTION>
<OPTION>12</OPTION>
<OPTION>13</OPTION>
<OPTION>14</OPTION>
<OPTION>15</OPTION>
<OPTION>16</OPTION>
<OPTION>17</OPTION>
<OPTION>18</OPTION>
<OPTION>19</OPTION>
<OPTION>20</OPTION>
<OPTION>21</OPTION>
<OPTION>22</OPTION>
<OPTION>23</OPTION>
<OPTION>24</OPTION>
<OPTION>25</OPTION>
<OPTION>26</OPTION>
<OPTION>27</OPTION>
<OPTION>28</OPTION>
<OPTION>29</OPTION>
<OPTION>30</OPTION>
<OPTION>31</OPTION>
</SELECT>

MONTH :
<SELECT NAME=MONTH>
<OPTION>JANUARY</OPTION>
<OPTION>FEBRUARY</OPTION>
<OPTION>MARCH</OPTION>
<OPTION>APRIL</OPTION>
<OPTION>MAY</OPTION>
<OPTION>JUNE</OPTION>
<OPTION>JULY</OPTION>
<OPTION>AUGUST</OPTION>
<OPTION>SEPTEMBER</OPTION>
<OPTION>OCTOBER</OPTION>
<OPTION>NAVEMBER</OPTION>
<OPTION>DECEMBER</OPTION>
</SELECT>

YEAR :
<SELECT NAME=YEAR>
<OPTION>1988</OPTION>
<OPTION>1989</OPTION>
<OPTION>1990</OPTION>
<OPTION>1991</OPTION>
<OPTION>1992</OPTION>
<OPTION>1993</OPTION>
<OPTION>1994</OPTION>
<OPTION>1995</OPTION>
<OPTION>1996</OPTION>
</SELECT>
</TD>
</TR>



<TR>
<TD> DEPARTMENT : </TD>
<TD>
<SELECT NAME=DEPARTMENT SIZE=3>
<OPTION VALUE=M.E.>M.E.</OPTION>
<OPTION VALUE=E.C.>E.C.</OPTION>
<OPTION VALUE=C.E.>C.E.</OPTION>
<OPTION VALUE=I.T.>I.T.</OPTION>
<OPTION VALUE=E.E.>E.E.</OPTION>
<OPTION VALUE=I.C.>I.C.</OPTION>
<OPTION VALUE=CH.E.>CH.E.</OPTION>
<OPTION VALUE=CL.E.>CL.E.</OPTION>
</SELECT>
</TD>
</TR>


<TR>
<TD> GENDER : </TD>
<TD><INPUT TYPE=RADIO NAME=RADIO VALUE=1 CHECKED> MALE
<INPUT TYPE=RADIO NAME=RADIO VALUE=2> FEMALE
</TD>
</TR>

<TR>
<TD> ENTER YOUR PICTURE : </TD>
<TD><INPUT TYPE=FILE NAME=IMAGE> <FONT SIZE=5 COLOR=BLUE> UPLOAD YOUR PHOTOGRAPH </FONT>
</TD>
</TR>


<TR>
<TD> LANGUAGE WHICH YOU KNOW : </TD>
<TD>
<INPUT TYPE=CHECKBOX NAME=ENGLISH VALUE=ENGLISH CHECKED> ENGLISH
<INPUT TYPE=CHECKBOX NAME=HINDI VALUE=HINDI> HINDI
<INPUT TYPE=CHECKBOX NAME=GUJARATI VALUE=GUJARATI> GUJARATI
</TD>
</TR>



<TR>
<TD> YEAR : </TD>
<TD>
<SELECT NAME=YEAR >
<OPTION VALUE=2009>2009</OPTION>
<OPTION VALUE=2010>2010</OPTION>
<OPTION VALUE=2011>2011</OPTION>
<OPTION VALUE=2012>2012</OPTION>
<OPTION VALUE=2013>2013</OPTION>
<OPTION VALUE=2014>2014</OPTION>
</SELECT>
</TD>
</TR>


<TR>
<TD> KNOWLEDGE : </TD>
<TD>
<INPUT TYPE=CHECKBOX NAME=C VALUE=C> C 
<INPUT TYPE=CHECKBOX NAME=C++ VALUE=C++> C++
<INPUT TYPE=CHECKBOX NAME=JAVA VALUE=JAVA> JAVA
<INPUT TYPE=CHECKBOX NAME=ASP.NET VALUE=ASP.NET> ASP.NET
<INPUT TYPE=CHECKBOX NAME=VB.NET VALUE=VB.NET> VB.NET
<INPUT TYPE=CHECKBOX NAME=DBMS VALUE=DBMS> DBMS
<INPUT TYPE=CHECKBOX NAME=LINUX VALUE=LINUX> LINUX
<INPUT TYPE=CHECKBOX NAME=VISUAL C++ VALUE=VISUAL C++> VISUAL C++
</TD>
</TR>


<TR>
<TD> DEGREE : </TD>
<TD>
<SELECT NAME=DEGREE>
<OPTION VALUE=B.TECH>B.TECH</OPTION>
<OPTION VALUE=M.TECH>M.TECH</OPTION>
<OPTION VALUE=DIPLOMA>DIPLOMA</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD> HOBBY : </TD>
<TD>
<INPUT TYPE=CHECKBOX NAME=MUSIC VALUE=MUSIC> MUSIC
<INPUT TYPE=CHECKBOX NAME=READING VALUE=READING> READING
<INPUT TYPE=CHECKBOX NAME=WRITING VALUE=WRITING> WRITING
<INPUT TYPE=CHECKBOX NAME=GAME VALUE=GAME> GAME
</TD>
</TR>




<TR>
<TD> COLLEGE NAME : </TD>
<TD><INPUT TYPE=TEXT NAME="COLLEGE NAME" VALUE="ENTER YOUR COLLEGE NAME" SIZE=30 MAXLENGTH=35></TD>
</TR>


<TR>
<TD> COLLEGE ADDRESS : </TD>
<TD><TEXTAREA COLS=50 ROWS=5 NAME="COLLEGE ADDRESS">
PLEASE ENTER YOUR COLLEGE ADDRESS....
</TEXTAREA>
</TD>
</TR>

<TR>
<TD> SUGGESION : </TD>
<TD><TEXTAREA COLS=20 ROWS=3 NAME="SUGGESSION">
PLEASE ENTER YOUR SUGGESSION HERE......
</TEXTAREA>
</TD> 
</TR>



<TR>
<TD>
<INPUT TYPE=SUBMIT VALUE="SUBMIT">
<INPUT TYPE=RESET VALUE="RESET">
</TD>
</TR>



</TABLE> 
</FORM>
<HR SIZE=15 NOSHADE>
</BODY>
</HTML>