<?php

$host="localhost"; // Host name 
$username=""; // Mysql username 
$password=""; // Mysql password 
$db_name="test"; // Database name 
$tbl_name="login"; // Table name 

// Connect to server and select databse.
$con = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");

// username and password sent from form 
$myusername=$_POST['myusername']; 
$mypassword=$_POST['mypassword']; 

$mypasswordmd5 = md5($mypassword);
$mypasswordsha1 = sha1($mypassword);
$mypasswordcrypt = crypt($mypassword);

$sql="insert into $tbl_name (username,passwordmd5,passwordsha1,passwordcrypt) values ('$myusername','$mypasswordmd5','$mypasswordsha1','$mypasswordcrypt')";

$result=mysqli_query($con,$sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row

if($count==1){
	
echo "Record inserted Successfully..!!";
}
else {
echo "Sorry..!! Something went wrong..!!";
}


?>